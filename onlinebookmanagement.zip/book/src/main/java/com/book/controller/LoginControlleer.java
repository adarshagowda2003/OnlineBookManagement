package com.book.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.book.entity.Admin;
import com.book.entity.User;
import com.book.service.AdminService;
import com.book.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class LoginControlleer {

	@Autowired
	UserService user;
	
	@Autowired
	AdminService admin;
	
	
	@GetMapping("/")
	public String home() {
		
	    return "home"; // Corrected spelling
	}

	
	@GetMapping("/userlogin")
	public String login() {
	
		return "userlogin";
	}
	
	@GetMapping("/adminlogin")
	public String adminlogin() {
		
		return "adminlogin";
		
	}
	
	@GetMapping("/userregister")
	public String userRegister() {
		
		return "userregister";
	}
	
	@GetMapping("/adminregister")
	public String adminRegister() {
		
		return "adminregister";
	}
	
	
	@PostMapping("/user/login")
	public String customerLogin(@RequestParam("email") String email,
			@RequestParam("password") String password,HttpSession session) {
		
		System.out.println("inside login");
		
		Optional<User> u = user.getByEmail(email);
		Optional<User> pu = user.getByPassword(password);
		if(u.isPresent() && pu.isPresent()) {
			session.setAttribute("userId", u.get().getId());
			return "redirect:/userhome";
		}
		
		else {
			return "userloginfail";
		}
		
		
	}
	
	@PostMapping("/admin/login")
	public String adminLogin(@RequestParam String email,
			@RequestParam String password,HttpSession session) {
		
		
		Optional<Admin> a1 = admin.getByEmail(email);
		Optional<Admin> a2 = admin.getBypassword(password);
		
		
		if(a1.isPresent() && a2.isPresent()) {
			session.setAttribute("adminId", a1.get().getId());
		
			return "redirect:/adminhome";
			
			
		}
		else {
			
			return "adminloginfail";
			
		}
		
		
	}
	
	
	
	
}
