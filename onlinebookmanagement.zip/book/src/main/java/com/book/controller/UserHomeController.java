package com.book.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.book.entity.Book;
import com.book.entity.User;
import com.book.service.BookService;
import com.book.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserHomeController {

	@Autowired
	BookService book;
	
	@Autowired
	UserService user;
	
	@GetMapping("/userhome")
	public String userHome(HttpSession session, Model model) {
	    int userId = (int) session.getAttribute("userId");

	    User u1 = user.getById(userId);

	    List<Book> newlist = book.getBookByCategory("new");
	    List<Book> oldlist = book.getBookByCategory("old");

	    model.addAttribute("userId", userId);
	    model.addAttribute("user", u1);
	    model.addAttribute("newBooks", newlist);  
	    model.addAttribute("oldBooks", oldlist); 

	    return "userhome";
	}

	@GetMapping("/user/profile/{userId}")
	public String userProfile(@PathVariable int userId,Model model) {
		
		User u = user.getById(userId);
		
		model.addAttribute("user",u);
		return "userprofile";
		
		
	}
	
	
	@PostMapping("/user/updateProfile")
	public String userUpdateProfile(@ModelAttribute User u) {
		
		user.userUpdate(u);
		return "redirect:/user/profile/"+u.getId();
		
		
	}
	
	@PostMapping("/admin/delete/{userId}")
	public String deleteUserAccount(@PathVariable int userId) {
		user.deleteUser(userId);
		return "redirect:/";
		
		
	}
	
	
	
	
}
