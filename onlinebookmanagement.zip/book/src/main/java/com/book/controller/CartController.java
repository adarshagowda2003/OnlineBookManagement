package com.book.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.book.entity.Admin;
import com.book.entity.Book;
import com.book.entity.Cart;
import com.book.entity.User;
import com.book.service.AdminService;
import com.book.service.BookService;
import com.book.service.CartService;
import com.book.service.UserService;

@Controller
public class CartController {

	@Autowired
	private CartService cart;

	@Autowired
	private BookService book;

	@Autowired
	private UserService user;

	@Autowired
	private AdminService admin;

	@GetMapping("/user/cart/{userId}")
	public String carts(@PathVariable int userId, Model model) {

		List<Cart> cartItems = cart.cartByUser(userId);

		model.addAttribute("cartitems", cartItems);


		model.addAttribute("userId", userId); 

		return "cart";
	}

	@GetMapping("/user/addcart/{bookId}/{userId}")
	public String addtoCart(@PathVariable int bookId,@PathVariable int userId,@ModelAttribute Cart c) {



		User u = user.getById(userId);

		Book b = book.getById(bookId);

		Admin a=b.getAdmin();


		Optional<Cart> matchingCart = cart.cartByUser(userId).stream()
				.filter(c1 -> c1.getBook().getId() == bookId)
				.findFirst();

		if (matchingCart.isPresent()) {
			Cart fc = matchingCart.get();

		
			
			fc.setQuantity(fc.getQuantity()+1);
			
			
			fc.setPriceAtAddition(fc.getPriceAtAddition()+b.getPrice());
			cart.addCart(fc);


		}
		else {
			
			c.setAdmin(a);
			c.setBook(b);
			c.setUser(u);
			
			double prc=b.getPrice()-( b.getPrice()* (Double.parseDouble(b.getOffer())/100));
			
			c.setPriceAtAddition(prc);
			c.setOfferAtAddition(b.getOffer());

			cart.addCart(c);

		}

		return "redirect:/user/cart/"+userId;
	}

	@PostMapping("/user/updatequantity/{id}")
	public String updateCartQuantity(@PathVariable int id, @RequestParam int quantity) {
		Cart c = cart.getById(id); 
		Book b = book.getById(c.getBook().getId());

		if (c != null) {

			c.setQuantity(quantity);
			
			double prc= b.getPrice()-((b.getPrice())*Integer.parseInt(b.getOffer())/100);
			
			c.setPriceAtAddition(prc * quantity);
			cart.addCart(c);

			return "redirect:/user/cart/" + c.getUser().getId();
		} else {


			return "redirect:/user/cart/error";
		}
	}

	@GetMapping("/user/removecart/{cartId}/{userId}")
	public String deleteCart(@PathVariable int cartId,@PathVariable int userId) {

		cart.deleteCart(cartId);

		return "redirect:/user/cart/"+userId;

	}


}
