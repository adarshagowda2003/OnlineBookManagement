package com.book.controller;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.book.entity.Admin;
import com.book.entity.Book;
import com.book.service.AdminService;
import com.book.service.BookService;

import org.springframework.ui.Model;

import jakarta.servlet.http.HttpSession;

@Controller
public class AdminHomeController {

	@Autowired
	BookService book;
	
	@Autowired
	AdminService admin;
	
	@GetMapping("/adminhome")
	public String adminHome(HttpSession session, Model model) {

	    List<Book> list = Collections.emptyList(); 
	    int adminId=0;
	    if (session.getAttribute("adminId") != null) {
	       adminId = (int) session.getAttribute("adminId");
	        list = book.getByAdminId(adminId);
	    }
	   
	    model.addAttribute("adminId",adminId);
	    
	    model.addAttribute("bookList", list);
	    model.addAttribute("adminId", adminId);
	    return "adminhome"; // Return view name
	}

	@GetMapping("admin/profile/{adminId}")
	public String adminProfile(@PathVariable int adminId , Model model) {
		
		System.out.println(adminId);
		
		Optional<Admin> a1 = admin.getById(adminId);
		
		if(a1.isPresent()) {
			
			model.addAttribute("admin",a1.get());
			return "adminprofile";
		}
		
		return "redirect:/adminhome";
	
	}

	@PostMapping("/admin/updateProfile")
public String updateAdmin(@ModelAttribute Admin a) {
		admin.addAdmin(a);
		
		return "redirect:/admin/profile/" + a.getId();

	
}
	
	
	
	
}
