package com.book.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.book.entity.Admin;
import com.book.entity.Book;
import com.book.entity.Cart;
import com.book.entity.Order;
import com.book.entity.User;
import com.book.service.AdminService;
import com.book.service.BookService;
import com.book.service.CartService;
import com.book.service.MailSenderService;
import com.book.service.OrderService;
import com.book.service.UserService;

@Controller
public class OrderController {

	@Autowired
	private  BookService book;
	
	@Autowired
	private UserService user;
	
	@Autowired
	private CartService cart;
	
	@Autowired
	private AdminService admin;
	
	@Autowired
	private OrderService order1;
	
	@Autowired
	private MailSenderService mail;

	@PostMapping("/user/placeorder")
	public String addOrder(@RequestParam("cartItemId") int cartItemId,
	        @RequestParam("userId") int userId,
	        @RequestParam("bookId") int bookId,
	        @RequestParam("paymentMode") String paymentMode,@ModelAttribute  Order o) {
		System.out.println("Inside addOrder 1");
		
		System.out.println(cartItemId+" "+userId+" "+bookId+" "+paymentMode);
		
		
		Cart c = cart.getById(cartItemId);
		User u = user.getById(userId);
		Book b = book.getById(bookId);
		Admin a = b.getAdmin();
		System.out.println("Inside addOrder 2");
		o.setAdmin(a);
		o.setBook(b);
		
		o.setUser(u);
		
		o.setPaidAmount(c.getPriceAtAddition());
		o.setQuantity(c.getQuantity());
		o.setPaymentMode(paymentMode);
		
		String toEmail=o.getUser().getEmail();
		
	
		
		
		String body="Hell user "+o.getUser().getName()+" you are Ordered "+o.getBook().getBookName()+
				" You paid Amount is "+o.getPaidAmount()+" you will get Your Order Soon";
		
		
		System.out.println(toEmail+"\n"+body);
		
		System.out.println("Mail sending");
		mail.sendMail(toEmail, body);
		
		
		
		order1.addOrder(o);
		System.out.println("Mail Sended successfully");
		
		return "redirect:/user/orders/"+u.getId();
		
		
	}
	
	@GetMapping("/user/orders/{userId}")
	public String showOrders(@PathVariable int userId,Model model) {
		List<Order> list = order1.getByUserid(userId);
		
		model.addAttribute("orders",list);
		
		return "userorders";
		
	}

	@GetMapping("/admin/orders/{adminId}")
	public String adminOrders(@PathVariable int adminId,Model model) {
		List<Order> list = order1.getByAdminid(adminId);
		
		for(Order x:list) {
			System.out.println(x);
		}
		
		model.addAttribute("adminorders",list);
		
		return "adminorders";
		
	}

}
