package com.book.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.book.entity.Admin;
import com.book.entity.Book;
import com.book.service.AdminService;
import com.book.service.BookService;

import jakarta.servlet.http.HttpSession;

@Controller
public class BookController {

	@Autowired
	BookService book;
	
	@Autowired
	AdminService admin;
	
	
	@PostMapping("/admin/addbook")
	public String addBook(@ModelAttribute Book b,HttpSession session) {
		
		
		if(session.getAttribute("adminId")!=null) {
			int adminId=(int)session.getAttribute("adminId");
			
			Admin a1 = admin.getById(adminId).get();
			
			b.setAdmin(a1);
			
			book.addBook(b);
			return "redirect:/adminhome";
		}
		return "adminloginfail";

	}
	
	
	@RequestMapping("/admin/deletebook/{bookId}")
	public String deleteBook(@PathVariable int bookId) {
		book.deleteByID(bookId);
		
		return "redirect:/adminhome";
		
	}
	
	
	@PostMapping("/admin/updatebook")
	public String updateBook(@ModelAttribute Book b,HttpSession session) {
		

		if(session.getAttribute("adminId")!=null) {
			int adminId=(int)session.getAttribute("adminId");
			
			Admin a1 = admin.getById(adminId).get();
			
			b.setAdmin(a1);
			
			book.addBook(b);
			return "redirect:/adminhome";
		}
		return "adminloginfail";
		
		
	}

}
