package com.book.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.book.entity.Admin;
import com.book.entity.User;

@Repository
public interface AdminRepository extends JpaRepository<Admin, Integer> {


	 Optional<Admin> findByEmail(String email);
	 
	 Optional<Admin> findByPassword(String password);
}
