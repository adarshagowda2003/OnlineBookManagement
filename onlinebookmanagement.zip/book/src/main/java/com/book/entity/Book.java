package com.book.entity;

import jakarta.persistence.*;

@Entity
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String bookName;
    private String author;
    private String StoreName;
    private String category;
    private boolean isAvailable;
    private double price;
    private String offer;      
    private String bookImage;  
    private String description;

   
    @ManyToOne
    @JoinColumn(name = "admin_id", referencedColumnName = "id")
    private Admin admin;

    public Book() {
    }

    public Book(String bookName,String author,String StoreName, String category, boolean isAvailable, double price, String offer, String bookImage, String description, Admin admin) {
        this.bookName = bookName;
        this.author=author;
        this.StoreName=StoreName;
        this.category = category;
        this.isAvailable = isAvailable;
        this.price = price;
        this.offer = offer;
        this.bookImage = bookImage;
        this.description = description;
        this.admin = admin;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public String getBookName() {
        return bookName;
    }

    public String getCategory() {
        return category;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public double getPrice() {
        return price;
    }

    public String getOffer() {
        return offer;
    }

    public String getBookImage() {
        return bookImage;
    }

    public String getDescription() {
        return description;
    }

    public Admin getAdmin() {
        return admin;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setOffer(String offer) {
        this.offer = offer;
    }

    public void setBookImage(String bookImage) {
        this.bookImage = bookImage;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setAdmin(Admin admin) {
        this.admin = admin;
    }

	public String getStoreName() {
		return StoreName;
	}

	public void setStoreName(String storeName) {
		StoreName = storeName;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	@Override
	public String toString() {
		return "Book [id=" + id + ", bookName=" + bookName + ", author=" + author + ", StoreName=" + StoreName
				+ ", category=" + category + ", isAvailable=" + isAvailable + ", price=" + price + ", offer=" + offer
				+ ", bookImage=" + bookImage + ", description=" + description + ", admin=" + admin + "]";
	}

	

}
