package com.book.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

@Entity
@Table(name = "orders") 
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "adminid", referencedColumnName = "id")
    private Admin admin;

    @ManyToOne
    @JoinColumn(name = "userid", referencedColumnName = "id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "bookid", referencedColumnName = "id")
    private Book book;

   

    private String paymentMode;

    private int quantity;

    private double paidAmount;

    @Column(name = "ordered_date", updatable = false)
    private LocalDateTime orderedDate;

    // ... constructors ...

   

    public Order() {
        super();
    }

    public Order(Admin admin, User user, Book book, String paymentMode, int quantity, double paidAmount) {
        this.admin = admin;
        this.user = user;
        this.book = book;
        
        this.paymentMode = paymentMode;
        this.quantity = quantity;
        this.paidAmount = paidAmount;
    }

   
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Admin getAdmin() {
        return admin;
    }

    public void setAdmin(Admin admin) {
        this.admin = admin;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

   

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(double paidAmount) {
        this.paidAmount = paidAmount;
    }

   

    public LocalDateTime getOrderedDate() {
		return orderedDate;
	}

    @PrePersist
    public void setOrderedDate() {
        this.orderedDate = LocalDateTime.now();
    }


	@Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", admin=" + (admin != null ? admin.getId() : null) +
                ", user=" + (user != null ? user.getId() : null) +
                ", book=" + (book != null ? book.getId() : null) +
                
                ", paymentMode='" + paymentMode + '\'' +
                ", quantity=" + quantity +
                ", paidAmount=" + paidAmount +
                ", orderedDate=" + orderedDate +
                '}';
    }
}