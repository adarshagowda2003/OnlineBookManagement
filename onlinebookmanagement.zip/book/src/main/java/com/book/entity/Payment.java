package com.book.entity;

import jakarta.persistence.Entity;

@Entity
public class Payment {

	private int id;
	
	private String name;
	
	private double price;
	
	private boolean status;
	
	
	
	
}
