package com.book.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "book_id", referencedColumnName = "id", nullable = false)
    private Book book;

    @ManyToOne
    @JoinColumn(name = "admin_id", referencedColumnName = "id", nullable = false)
    private Admin admin;

    @Column(nullable = false)
    private int quantity;

    private LocalDateTime addedDate;

    private double priceAtAddition;

    private String offerAtAddition;

    public Cart() {
        this.quantity = 1;
        this.addedDate = LocalDateTime.now();
    }

    public Cart(User user, Book book, Admin admin, double priceAtAddition, String offerAtAddition) {
        this.user = user;
        this.book = book;
        this.admin = admin;
        this.quantity = 1;
        this.addedDate = LocalDateTime.now();
        this.priceAtAddition = priceAtAddition;
        this.offerAtAddition = offerAtAddition;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public Admin getAdmin() {
        return admin;
    }

    public void setAdmin(Admin admin) {
        this.admin = admin;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public LocalDateTime getAddedDate() {
        return addedDate;
    }

    public void setAddedDate(LocalDateTime addedDate) {
        this.addedDate = addedDate;
    }

    public double getPriceAtAddition() {
        return priceAtAddition;
    }

    public void setPriceAtAddition(double priceAtAddition) {
        this.priceAtAddition = priceAtAddition;
    }

    public String getOfferAtAddition() {
        return offerAtAddition;
    }

    public void setOfferAtAddition(String offerAtAddition) {
        this.offerAtAddition = offerAtAddition;
    }

    @Override
    public String toString() {
        return "Cart{" +
               "id=" + id +
               ", user=" + (user != null ? user.getId() : null) +
               ", book=" + (book != null ? book.getId() : null) +
               ", admin=" + (admin != null ? admin.getId() : null) +
               ", quantity=" + quantity +
               ", addedDate=" + addedDate +
               ", priceAtAddition=" + priceAtAddition +
               ", offerAtAddition='" + offerAtAddition + '\'' +
               '}';
    }
}