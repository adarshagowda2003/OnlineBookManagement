package com.book.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Admin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;
    private String bookstorename;
    private String city;
    private String address;
    private String password;
    private String email; 

    @Column(name = "registration_date", updatable = false)
    private LocalDate registrationDate;

    public Admin() {
    }

    public Admin(String name, String bookstorename, String city, String address, String password, String email) {
        this.name = name;
        this.bookstorename = bookstorename;
        this.city = city;
        this.address = address;
        this.password = password;
        this.email = email;
    }
    
    
    
    

    public Admin(int id, String name, String bookstorename, String city, String address, String password, String email
			) {
		super();
		this.id = id;
		this.name = name;
		this.bookstorename = bookstorename;
		this.city = city;
		this.address = address;
		this.password = password;
		this.email = email;
		
	}

	// Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getBookstorename() {
        return bookstorename;
    }

    public String getCity() {
        return city;
    }

    public String getAddress() {
        return address;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public LocalDate getRegistrationDate() {
        return registrationDate;
    }

    
    
    
    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
		this.id = id;
	}

	public void setBookstorename(String bookstorename) {
        this.bookstorename = bookstorename;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @PrePersist
    public void prePersist() {
        this.registrationDate = LocalDate.now();
    }

    
    @Override
    public String toString() {
        return "Admin [id=" + id + ", name=" + name + ", bookstorename=" + bookstorename + ", city=" + city
                + ", address=" + address + ", password=" + password + ", email=" + email + ", registrationDate=" + registrationDate + "]";
    }
}
