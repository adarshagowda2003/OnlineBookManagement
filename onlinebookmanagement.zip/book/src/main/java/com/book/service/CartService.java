package com.book.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.entity.Cart;
import com.book.repository.CartRepository;

@Service
public class CartService {

	
	@Autowired
	CartRepository cart;

	public void addCart(Cart c) {
		
		cart.save(c);
	
	}
	
	public List<Cart> getCarts() {
		return cart.findAll();
	}
	
	
	public List<Cart> cartByUser(int userId) {
	return	cart.findByUser_Id(userId);
	}
	
	
	public Cart getById(int id) {
	return	cart.findById(id).get();
	}
	
	
	public void deleteCart(int id) {
		cart.deleteById(id);
	}
	
}
