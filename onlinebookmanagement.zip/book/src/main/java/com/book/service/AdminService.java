package com.book.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.entity.Admin;
import com.book.repository.AdminRepository;

@Service
public class AdminService {

	@Autowired
	AdminRepository admin;
	
	
	public List<Admin>  getAllAdmins() {
		
		return admin.findAll();
		
	}

	public Optional<Admin> getById(int id) {
		
		return admin.findById(id);
		
	}
	
	public void addAdmin(Admin a) {
		admin.save(a);
	}
	
	public void deleteById(int id) {
		
		admin.deleteById(id);
	}
	
	public Optional<Admin> getByEmail(String email) {
		return admin.findByEmail(email);
		
	}
	
	public Optional<Admin> getBypassword(String password) {
		return admin.findByPassword(password);
		
	}
	
	public void updateAdmin(Admin a) {
		admin.save(a);
	}
	
}
