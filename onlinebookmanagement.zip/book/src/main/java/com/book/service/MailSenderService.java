package com.book.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class MailSenderService {

	@Autowired
	private JavaMailSender sender;

	public void sendMail(String toEmail,String body) {
		
		SimpleMailMessage mail = new SimpleMailMessage();
		
		mail.setFrom("adarshagowdav003@gmail.com");
		mail.setTo(toEmail);
		mail.setSubject("Hello !! We are from BookManagement");
		mail.setText(body);
		
		sender.send(mail);
		
	}
	
	
	
	
}
