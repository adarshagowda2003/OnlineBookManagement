package com.book.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.entity.User;
import com.book.repository.UserRepository;
@Service
public class UserService {

	@Autowired
	private UserRepository user;
	
	
	public List<User> getAllUser() {
		
		return user.findAll();
		
	}
	
	
	public User getById(int id) {
		return user.findById(id).get();
		
	}
	
	public void addUesr(User u) {
	user.save(u);
		
	}
	
    public void userUpdate(User u) {
    	
    	user.save(u);
    }
	
	
	
	public void deleteUser(int id) {
		user.deleteById(id);;
	}
	
	  public  Optional<User> getByEmail(String email) {
	  return user.findByEmail(email);
	  }
	
	  
	  public  Optional<User> getByPassword(String password) {
		  return user.findByPassword(password); 
		  
	  }
	  
	  
	  
}
