package com.book.service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.entity.Book;
import com.book.repository.BookRepository;

@Service
public class BookService {

	@Autowired
	BookRepository bookRepo;
	
	public void addBook(Book b) {
		bookRepo.save(b);	
	}

	public List<Book> getAllBooks() {
		return bookRepo.findAll();
		
	}
	
	
	public Book getById(int id) {
		
		return bookRepo.findById(id).get();
	}
	
	
	public Book findById(int id) {
	return	bookRepo.findById(id).get();
	}
	
	public List<Book> getByAdminId(int id) {
	    List<Book> books = bookRepo.findByAdminId(id);
	    
	    if (books == null || books.isEmpty()) {
	        return Collections.emptyList(); 
	    }
	    
	    return books;
	}
	
	
	public void deleteByID(int id) {
		
		bookRepo.deleteById(id);
		
		
	}
	
	
	
	public List<Book> getBookByCategory(String category) {
	return bookRepo.findByCategory(category);
		
		
	}
	
	
	
}
