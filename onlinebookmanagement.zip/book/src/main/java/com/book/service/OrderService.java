package com.book.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.entity.Order;
import com.book.repository.OrderRepository;

@Service
public class OrderService {

	@Autowired
	private OrderRepository order;
	
	
	public void addOrder(Order o) {
		
		order.save(o);
		
	}

	public List<Order> getByAdminid(int adminId) {
		return order.findByAdminId(adminId);
	}
	
	public List<Order> getByUserid(int userId) {
		return order.findByUserId(userId);
	}
	
}
